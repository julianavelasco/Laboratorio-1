class Main {
  public static void main(String[] args) {
    //Ejecuta Run en la parte superior para compilar
    System.out.println("Dirijase a T.java");
    System.out.println("Ejecute en la consola: ");
    System.out.println("java -classpath :/run_dir/junit-4.12.jar:target/dependency/* T");
  }
}