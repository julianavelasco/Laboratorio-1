import java.util.Scanner;
public class T extends Thread {

  private String name;
  private static int limite;
  private static int milisegundos;
  
  public T(String name){
    this.name=name;
  }
 public void run () {
    if(this.name.equals("Thread par")){
      for(int i=0; i<=limite; i+=2){
        System.out.println("Par: "+i);
        try{
          Thread.sleep(milisegundos);
        }
        catch(Exception e){
          System.out.println("Saliendo: "+name);
        }
      }
    }
    else if(this.name.equals("Thread impar")){
      for(int i=1; i<=limite; i+=2){
        System.out.println("Impar: "+i);
        try{
          Thread.sleep(milisegundos);
        }
        catch(Exception e){
          System.out.println("Saliendo: "+name);
        }
      }
    }
  }
 public static void main(String[] args) {
      Scanner in = new Scanner(System.in);
      System.out.print("Ingresar límite superior: ");
      limite = in.nextInt();
      System.out.print("Ingresar milisegundos: ");
      milisegundos = in.nextInt();
      in.close();
      T t1=new T ("Thread par");
      T t2=new T("Thread impar");
      t1.start();
      t2.start();
 } 
}